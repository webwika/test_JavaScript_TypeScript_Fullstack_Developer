
function isValidSubsequence(array, sequence) {
    // code here
}

module.exports = {
    isValidSubsequence,
};
