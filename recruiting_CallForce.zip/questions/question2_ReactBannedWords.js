
const bannedWords = [ '123', '321' ];

function validateText(text) {
	// code here
}

module.exports = {
	validateText,
};